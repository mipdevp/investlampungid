console.error('code.highcharts.local has moved to the /code folder'); // eslint-disable-line no-console
